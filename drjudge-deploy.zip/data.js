/* ============================================
   Dr.Judge — 목업 데이터 (API 연동 시 이 파일만 교체)
   ============================================ */

/* categoryId → 화면 문구.
   서버 categories 테이블의 id 를 그대로 씁니다 (2026.08.19 확인).
   0번은 화면 전용(전체 보기)이라 서버에는 없습니다. */
const CATEGORIES = [
  '전체 카테고리', // 0 — 화면 전용
  '영양제·건강기능식품', // 1 NUTRITION
  '다이어트·체중관리', // 2 DIET
  '질환·증상관리', // 3 DISEASE_CARE
  '화장품', // 4 COSMETICS
  '시술·피부관리', // 5 PROCEDURE_SKINCARE
];

const BRIEFINGS = [
  {
    id: 'b1',
    title: '오늘 주목할 건강 이슈는?',
    desc: '매일 1분, 검증된 건강·미용 정보 브리핑',
    cta: '브리핑 확인하기',
  },
  {
    id: 'b2',
    title: '이번 주 화제의 성분 TOP 3',
    desc: '검색량이 급증한 성분을 정리했어요',
    cta: '브리핑 확인하기',
  },
  {
    id: 'b3',
    title: '가짜뉴스 판정 결과 모아보기',
    desc: 'Dr.Judge가 검증한 이번 주 루머',
    cta: '브리핑 확인하기',
  },
  {
    id: 'b4',
    title: '내 관심 카테고리 브리핑',
    desc: '관심 주제만 골라 받아보세요',
    cta: '브리핑 확인하기',
  },
];

const FEEDS = [
  {
    id: 'f1',
    category: '건강/면역',
    title: '비타민C 고함량 제품 정말 더 좋을까?',
    desc: '고함량 비타민 C 섭취 시 면역력 강화 효과는 제한적일 수 있다는 연구 결과가 나왔어요.',
    author: '건강정보러버',
    createdAt: '2026-08-10T09:00:00',
    likes: 128,
    liked: false,
  },
  {
    id: 'f2',
    category: '다이어트',
    title: '공복 유산소, 체지방 감소에 도움될까?',
    desc: '공복 유산소 운동이 체지방 감소에 미치는 영향에 대한 전문가 의견을 정리했어요.',
    author: '오늘부터운동',
    createdAt: '2026-08-11T13:20:00',
    likes: 96,
    liked: false,
  },
  {
    id: 'f3',
    category: '미용/화장품',
    title: "'PDRN 화장품' 효과, 임상으로 입증됐을까?",
    desc: 'PDRN 성분의 피부 재생 효과에 대한 임상 연구 결과를 확인해봤어요.',
    author: '피부는과학',
    createdAt: '2026-08-12T18:40:00',
    likes: 231,
    liked: true,
  },
  {
    id: 'f4',
    category: '질환·증상관리',
    title: '양배추즙, 위염에 도움이 될까?',
    desc: '양배추즙이 위염 증상 완화에 도움이 된다는 주장, 사실인지 알아봤어요.',
    author: '건강한일상',
    createdAt: '2026-08-11T08:10:00',
    likes: 74,
    liked: false,
  },
  {
    id: 'f5',
    category: '기타',
    title: '아침 사과가 몸에 더 좋다는 말, 근거 있나?',
    desc: '섭취 시간대에 따른 영양 흡수 차이를 다룬 자료를 살펴봤어요.',
    author: '팩트체커',
    createdAt: '2026-08-09T07:30:00',
    likes: 45,
    liked: false,
  },
];

/* ============================================
   피드 탭 · 마이페이지 데이터
   ============================================ */

/* 판정 결과 뱃지 */
const RESULT = {
  expert: { label: '전문가 의견 있음', hint: '근거 확인', tone: 'ok', icon: 'check' },
  lack: { label: '근거 부족', hint: '확인 기준 필요', tone: 'warn', icon: 'bang' },
  hold: { label: '판단보류', hint: '추가 근거 확인', tone: 'hold', icon: 'question' },
};

/* 공유 피드 카드 */
const FEED_CARDS = [
  {
    id: 'c1',
    category: '건강 · 질환/증상관리',
    title: '혈당을 낮추려면 식후 10분만 걸어도 효과가 있다?',
    desc: '식후 가벼운 걷기가 혈당 관리에 도움이 될 수 있지만, 개인의 상태와 운동 강도에 따라 차이가 있습니다.',
    result: 'expert',
    author: '건강확인러',
    likes: 128,
    createdAt: '2026-08-12T09:41:00',
  },
  {
    id: 'c2',
    category: '미용 · 화장품',
    title: '모공을 완전히 없애주는 홈케어 제품이 있다?',
    desc: '화장품으로 모공 자체를 완전히 없애는 것은 어렵습니다. 제품의 효과는 피부 상태와 성분에 따라 달라집니다.',
    result: 'lack',
    author: '뷰티체크',
    likes: 94,
    createdAt: '2026-08-11T16:22:00',
    detail: {
      verdict: '근거 부족',
      summary: '임상적 근거 없음',
      info: [
        ['대상', '성인 일반'],
        ['효과', '피부 모공 개선'],
        ['조건 · 범위', '일반적 사용 조건 기준'],
        ['근거 버전', 'v2024.11'],
      ],
      evidence:
        '모공은 피부 상태(피지 분비, 탄력, 각질 등)에 따라 일시적으로 가려지거나 눈에 덜 띌 수는 있으나, 화장품만으로 모공을 완전히 없애는 것은 어렵습니다. 현재까지 ‘모공을 완전히 없앤다’는 주장을 뒷받침하는 임상적 근거는 확인되지 않았습니다.',
      checkpoints: [
        '제품이 ‘의약품’이 아닌 ‘화장품’인지 확인',
        '과장 광고 여부 확인 (식약처 기능성 심사 여부 확인)',
        '전성분 및 주요 기능성 성분(피지·각질 관리 성분) 확인',
        '피부 타입에 맞는 제품 선택 및 패치 테스트 권장',
      ],
    },
  },
  {
    id: 'c3',
    category: '이너뷰티 · 건강기능식품',
    title: '비타민을 많이 먹을수록 면역력이 계속 올라간다?',
    desc: '필요량을 넘어선 섭취가 효과를 계속 높인다고 보기는 어렵습니다. 제품의 공식 함량과 섭취 기준을 확인하세요.',
    result: 'hold',
    author: '웰니스노트',
    likes: 71,
    createdAt: '2026-08-10T11:30:00',
  },
];

const HISTORY_STATUS = {
  fit: { label: '적합', hint: '근거 충분', mark: '✓' },
  vague: { label: '애매', hint: '정보 부족', mark: '?' },
  unfit: { label: '부적합', hint: '근거 부족', mark: '×' },
};


/* ============================================
   판정 결과 데이터
   ============================================ */

/* 근거 계층 라벨 — 신뢰도 5단계 */
/* 근거 계층 라벨 5단계
   icon   원 안에 들어가는 글자 (화면 목업 기준)
   action 오른쪽에 붙는 안내 문구
   score  5칸짜리 막대에서 채울 칸 수 */
const EVIDENCE_LEVELS = [
  {
    key: 'clinical',
    name: '임상적 근거 있음',
    icon: 'O',
    action: '신뢰도 최고',
    trust: '최고',
    score: 5,
    desc: '과학적 증거가 명확하고 전문 기관의 승인을 받은 정보입니다.',
    example: '식약처 승인 효능, 국가 임상 가이드라인, 동료 검토 임상연구',
  },
  {
    key: 'expert',
    name: '전문가 의견 있음',
    icon: '✓',
    action: '근거 확인',
    trust: '높음',
    score: 4,
    desc: '임상 근거는 없으나 신뢰할 수 있는 전문가가 지지하는 정보입니다.',
    example: '공인된 의료 전문가의 코멘트, 학회 발표, 전문가 인터뷰',
  },
  {
    key: 'hold',
    name: '판단보류',
    icon: '?',
    action: '추가 근거 확인',
    trust: '보통',
    score: 3,
    desc: '상반된 근거가 존재하거나 정보가 불완전해 명확한 판단이 어렵습니다.',
    example: '찬성과 반대 연구가 함께 존재, 대상이 불명확, 조건 범위 불일치',
  },
  {
    key: 'lack',
    name: '근거 부족',
    icon: 'x',
    action: '확인 기준 필요',
    trust: '낮음',
    score: 2,
    desc: '현재 확인된 과학적 근거가 부족합니다. 이는 거짓이 아니라 아직 충분하지 않음을 의미합니다.',
    example: '가설 단계, 소규모 연구만 존재, 공식 기준 부재',
  },
  {
    /* 목업에는 4단계까지만 그려져 있지만, 서버가 '반박 근거 있음'을 보낼 수 있어
       설명 화면에서 빠지면 안 됩니다. 문구가 마음에 안 들면 action 만 고치면 됩니다. */
    key: 'refuted',
    name: '반박 근거 있음',
    icon: '!',
    action: '주의 필요',
    trust: '매우 낮음',
    score: 1,
    desc: '신뢰할 수 있는 과학적 근거가 해당 주장을 뒷받침하지 않습니다.',
    example: '대규모 임상연구 반박, 식약처 미승인, 공식 가이드라인 불일치',
  },
];

/* 판정 결과 카드에 붙는 짧은 부연 (라벨 이름 옆 괄호) */
const LEVEL_SUFFIX = {
  clinical: '임상 근거 확인',
  expert: '전문가 의견 확인',
  hold: '근거 엇갈림',
  lack: '임상적 근거 없음',
  refuted: '반박 근거 있음',
};

const levelOf = (key) => EVIDENCE_LEVELS.find((l) => l.key === key) || null;

/* 판정 결과 샘플 (실제로는 서버 응답으로 교체) */
const RESULT_SAMPLE = {
  claim: '이 유산균은 혈당 수치 개선에 도움이 된다',
  level: 'clinical',
  conflict: true,
  sources: ['식약처 공식 기준', '대한의학회 임상 가이드라인'],
  core: [
    ['대상', '성인'],
    ['효과', '혈당 수치 개선'],
    ['조건', '1일 1회, 식후 복용'],
  ],
  scope:
    '이 근거는 건강한 성인을 대상으로 한 연구에서 나온 결과입니다. 당뇨병이 있는 경우 담당 의료진과 상담 후 사용해주세요.',
  caution: '이 서비스는 의료 진단·처방을 대체하지 않습니다. 증상이 있다면 전문가와 상담하세요.',
};

/* 구매 기준 카드 */
const BUY_CRITERIA = [
  {
    title: '영양제 확인 사항',
    items: [
      ['식약처 인증 여부', '건강기능식품 마크가 있는지 확인하세요'],
      ['주요 성분 함량', '1일 섭취량과 함유량이 표시되어 있어야 합니다'],
      ['제조사 정보', '회사명과 제조일자, 유통기한을 확인하세요'],
    ],
  },
  {
    title: '화장품 확인 사항',
    items: [
      ['피부 타입과 민감도', '본인의 피부 상태와 성분 알레르기를 고려해 선택하세요'],
      ['성분 확인', '자극 성분 배제와 유효 성분 함유 여부를 점검하세요'],
      ['제품 평가 및 후기', '객관적인 피부 반응 데이터를 참고하는 것이 도움됩니다'],
    ],
  },
];

/* ============================================
   오늘의 브리핑
   ============================================ */
const BRIEFING_TODAY = {
  keywords: ['비타민C', '공복 유산소', "'PDRN 화장품'"],
  stats: [
    ['총 콘텐츠', '23건'],
    ['주목도 상승 키워드', '5건'],
    ['유저 관심 콘텐츠', 'TOP 3'],
  ],
};


/* ============================================
   온보딩 선택지 — 화면 문구 ↔ 서버 값
   서버 enum 이 확정되면 value 만 고치면 됩니다.
   ============================================ */
/* 서버 categories 테이블의 code 와 name 을 그대로 옮긴 것입니다.
   표에 없는 코드를 보내면 400 CATEGORY_001 이 옵니다
   (예전 NUTRITION_SUPPLEMENT·ETC 는 서버에 없는 값이었습니다). */
const INTEREST_OPTIONS = [
  { label: '영양제·건강기능식품', value: 'NUTRITION' },
  { label: '다이어트·체중관리', value: 'DIET' },
  { label: '질환·증상관리', value: 'DISEASE_CARE' },
  { label: '화장품', value: 'COSMETICS' },
  { label: '시술·피부관리', value: 'PROCEDURE_SKINCARE' },
];

const AGE_OPTIONS = [
  { label: '10~24세', value: 'AGE_10S' },
  { label: '25~39세', value: 'AGE_20S' },
  { label: '40~59세', value: 'AGE_40S' },
  { label: '60세 이상', value: 'AGE_60S_PLUS' },
];

const GENDER_OPTIONS = [
  { label: '여성', value: 'FEMALE' },
  { label: '남성', value: 'MALE' },
  { label: '기타', value: 'UNKNOWN' },
];

/* 나이대는 화면 선택지(4구간)와 서버 값(10년 단위)이 아직 안 맞습니다.
   서버가 AGE_50S 처럼 표에 없는 값을 줘도 'AGE_50S' 를 그대로 보여주지 않도록
   '50대' 로 바꿔 읽습니다. (표에 있으면 표를 먼저 씁니다) */
const ageLabelOf = (value) => {
  if (!value) return null;
  const known = AGE_OPTIONS.find((o) => o.value === value);
  if (known) return known.label;

  const m = /^AGE_(\d+)S(_PLUS)?$/.exec(value);
  if (m) return m[2] || m[1] === '60' ? '60세 이상' : m[1] + '대'; // _PLUS 는 항상 '이상'
  return value;
};

const labelToValue = (list, label) =>
  (list.find((o) => o.label === label) || {}).value || null;
const valueToLabel = (list, value) =>
  (list.find((o) => o.value === value) || {}).label || value;

/* ============================================
   포인트 사유 코드 → 화면 문구 (7.2)
   확인된 값: DAILY_LOGIN, FEED_POST
   나머지는 예상값이라, 서버에 없는 코드가 와도
   '포인트 적립 / 포인트 사용'으로 안전하게 표시됩니다.
   ============================================ */
const POINT_REASON = {
  DAILY_LOGIN: '매일 접속',
  FEED_POST: '공유 카드 게시',
  SIGNUP: '가입 축하',
  ONBOARDING: '관심 분야 설정',
  JUDGMENT: '판정 완료',
  JUDGEMENT: '판정 완료',
  SHARE: '판정 결과 공유',
  LIKE_RECEIVED: '좋아요 받기',
  EVENT: '이벤트 보상',
  ADMIN: '관리자 조정',
  REWARD_EXCHANGE: '리워드 교환',
  GIFTICON: '기프티콘 교환',
};
