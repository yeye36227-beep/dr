/* ============================================
   Dr.Judge — API 래퍼
   백엔드 연동 시 이 파일만 수정하면 됩니다.

   1) BASE_URL 을 실제 서버 주소로 변경
   2) 아래 LIVE 에서 서버에 준비된 기능을 true 로 변경
   3) 응답 형태가 다르면 ERROR_MESSAGE / statusMap 만 수정
   ============================================ */

const API = (() => {
  /* ---------- 서버 주소 ----------
     배포된 백엔드입니다. 이 도메인은 CORS 에 drjudge.netlify.app 과
     localhost:3000 이 이미 열려 있습니다 (2026.08.19 확인).
     주소가 바뀌면 이 한 줄만 고치면 됩니다.

     주의: serve.py/serve.js 로 열면 이 값보다 '같은 주소(/api)'가 우선입니다.
           즉 로컬 개발은 예전처럼 내 컴퓨터의 백엔드를 계속 씁니다.
           배포 서버로 붙여 보려면 http://localhost:3000/start.html?api=server */
  const SERVER_URL = 'https://13-124-27-143.sslip.io';

  /* 내 컴퓨터에서 여는 중인지 — 주소 결정과 오류 문구에 씁니다 */
  const DEV_HOST = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);

  /* 로컬에서 열었더라도 배포 서버에 붙여 보고 싶을 때 씁니다 — ?api=server */
  const FORCE_SERVER = /[?&]api=server\b/.test(location.search);

  /* serve.js/serve.py(로컬 개발 서버)로 열면 화면과 /api 가 같은 주소라서
     주소를 따로 붙일 필요가 없습니다. 이때는 CORS 자체가 생기지 않습니다.
     서버가 HTML 에 표시를 심어 주므로 포트가 몇이든 알아서 잡힙니다. */
  const SAME_ORIGIN =
    !FORCE_SERVER &&
    (window.__SAME_ORIGIN_API === true || /[?&]api=same\b/.test(location.search));

  /* ---------- API 주소 결정 ----------
     위에서부터 먼저 맞는 것이 적용됩니다.

     1) serve.py/serve.js 로 열었으면  → /api  (같은 주소 = 내 컴퓨터 백엔드)
     2) SERVER_URL 이 적혀 있으면      → 그 주소  ← 지금은 배포 서버
     3) localhost 인데 1·2 가 아니면   → http://localhost:8080/api
     4) 그 밖                          → /api  (_redirects 프록시용 대비)

     예전에는 배포 도메인에서 'http://<사이트주소>:8080/api' 를 불렀습니다.
     그런 서버가 없을뿐더러 https 페이지에서 http 를 부르는 것이라
     브라우저가 요청 자체를 막았습니다 — Netlify 에서 가입이 안 되던 원인입니다. */
  const BASE_URL = SAME_ORIGIN
    ? '/api'
    : SERVER_URL
      ? SERVER_URL.replace(/\/$/, '') + '/api'
      : DEV_HOST
        ? 'http://' + location.hostname + ':8080/api'
        : '/api';

  const TIMEOUT = 8000;

  /* ---------- 어떤 기능을 실제 서버에 붙일지 ----------
     서버에 만들어진 것부터 하나씩 true 로 바꾸면 됩니다.
     false 인 기능은 서버 없이 브라우저 안에서 동작합니다. */
  const LIVE = {
    signup: true, // POST /auth/signup — 연동됨
    login: true, // POST /auth/login — 연동됨
    kakao: true, // POST /auth/kakao — 연동됨
    checkDuplicate: false, // 명세 대기
    judge: true, // POST·GET /judgements — 연동됨
    onboarding: true, // POST·PATCH /me/onboarding — 연동됨
    briefing: true, // GET /briefings/today — 연동됨
    share: true, // POST /judgments/{id}/share — 연동됨
    feed: true, // POST /feed/posts — 연동됨
    points: true, // GET /users/me/points/history — 연동됨
    profile: true, // GET /users/me — 연동됨
  };

  const live = (key) => LIVE[key] === true;



  /* ---------- 서버 에러코드 → 화면 오류 문구 ----------
     서버는 { code, message } 형태로 내려준다고 가정합니다.
     field 는 오류를 표시할 입력 칸(data-field 값)입니다. */
  const ERROR_MESSAGE = {
    USER_NOT_FOUND: { field: 'userId', text: '아이디를 다시 확인해 주세요.' },
    INVALID_PASSWORD: {
      field: 'password',
      text: '비밀번호를 다시 확인해 주세요.',
    },
    DUPLICATE_USER_ID: {
      field: 'userId',
      text: '이미 사용 중인 아이디예요.',
    },
    DUPLICATE_NICKNAME: {
      field: 'nickname',
      text: '이미 사용 중인 닉네임이에요.',
    },
    DUPLICATE_EMAIL: {
      field: 'email',
      text: '이미 가입된 이메일 주소예요.',
    },
    INVALID_EMAIL: {
      field: 'email',
      text: '이메일 주소를 다시 확인해 주세요.',
    },
    DAILY_LIMIT: {
      field: null,
      text: '오늘 판정 요청 한도에 도달했습니다.',
    },
    OCR_FAILED: {
      field: null,
      text: '이미지에서 텍스트를 읽지 못했어요.',
    },
    UNSUPPORTED_LINK: {
      field: null,
      text: '비공개·멤버십 콘텐츠는 추출이 제한될 수 있습니다.',
    },
    INVALID_INPUT: { field: null, text: '입력한 내용을 다시 확인해 주세요.' },
    INVALID_CREDENTIALS: {
      // 서버가 아이디/비밀번호를 구분하지 않으므로 두 칸 모두 표시합니다
      fields: ['userId', 'password'],
      field: null,
      text: '아이디 또는 비밀번호를 다시 확인해 주세요.',
    },
    WITHDRAWN_USER: { field: null, text: '이미 탈퇴한 계정이에요.' },
    FEED_BLOCKED: {
      field: null,
      text: '아직 게시할 수 없는 판정이에요. 판정이 끝난 뒤 다시 시도해 주세요.',
    },
    SHARE_NOT_FOUND: {
      field: null,
      text: '이미 회수됐거나 발급된 링크가 없어요.',
    },
    SHARE_GONE: {
      field: null,
      text: '더 이상 볼 수 없는 링크예요. 공유한 분에게 다시 요청해 주세요.',
    },
    INVALID_DATE: { field: null, text: '날짜 형식이 올바르지 않아요.' },
    BRIEFING_NOT_FOUND: { field: null, text: '이 날짜에는 브리핑이 없어요.' },
    SESSION_EXPIRED: {
      field: null,
      text: '로그인이 만료됐어요. 다시 로그인해 주세요.',
    },
    KAKAO_AUTH_FAILED: {
      field: null,
      text: '카카오 로그인이 취소됐거나 시간이 지났어요. 다시 시도해 주세요.',
    },
    NICKNAME_REJECTED: {
      field: 'nickname',
      text: '이미 사용 중이거나 쓸 수 없는 닉네임이에요.',
    },
    ONBOARDING_TOKEN_EXPIRED: {
      field: null,
      text: '인증 시간이 지났어요. 다시 로그인한 뒤 시도해 주세요.',
    },
    ONBOARDING_USER_NOT_FOUND: {
      field: null,
      text: '계정을 찾을 수 없어요. 다시 로그인해 주세요.',
    },
    FORBIDDEN: { field: null, text: '내가 요청한 판정만 볼 수 있어요.' },
    NOT_FOUND: { field: null, text: '판정 결과를 찾을 수 없어요.' },
    JUDGE_TIMEOUT: {
      field: null,
      text: '판정이 오래 걸리고 있어요. 잠시 후 판정 이력에서 확인해 주세요.',
    },
    SERVER_ERROR: { field: null, text: '서버에 문제가 생겼어요. 잠시 후 다시 시도해 주세요.' },
    NETWORK_ERROR: { field: null, text: '네트워크 연결을 확인해 주세요.' },
    /* serve.py / serve.js 가 백엔드에 못 닿을 때 돌려주는 코드입니다.
       이게 보이면 프론트는 정상이고 백엔드만 안 떠 있는 것입니다. */
    BACKEND_DOWN: {
      field: null,
      text: '백엔드 서버가 응답하지 않아요. 도커가 떠 있는지 확인해 주세요.',
    },
    UNKNOWN: { field: null, text: '잠시 후 다시 시도해 주세요.' },
  };

  function toError(code) {
    return { ok: false, code, ...(ERROR_MESSAGE[code] || ERROR_MESSAGE.UNKNOWN) };
  }

  /* ---------- 공통 fetch ----------
     서버는 이런 형태로 응답합니다.
       성공 { "success": true,  "data": {...}, "error": null }
       실패 { "success": false, "data": null,  "error": {...} }
     여기서 껍데기를 벗겨 화면에는 data 만 넘겨줍니다. */

  /* HTTP 상태코드 → 화면 오류코드 (엔드포인트별로 statusMap 으로 덮어쓸 수 있음) */
  const STATUS_FALLBACK = {
    400: 'INVALID_INPUT',
    401: 'INVALID_PASSWORD',
    403: 'FORBIDDEN',
    404: 'USER_NOT_FOUND',
    409: 'DUPLICATE_EMAIL',
    429: 'DAILY_LIMIT',
    500: 'SERVER_ERROR',
  };

  async function request(path, opts = {}) {
    const { method = 'GET', body, auth = true, statusMap, noRetry, own401, keepalive, _retried } =
      opts;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT);

    try {
      const res = await fetch(BASE_URL + path, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(auth && getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
        /* 화면을 옮기는 순간 보내는 요청은 keepalive 를 켭니다.
           안 켜면 이동하면서 요청이 끊겨 기록이 남지 않습니다. */
        keepalive: Boolean(keepalive),
      });

      const json = await res.json().catch(() => ({}));
      const err = json.error || {};

      // 토큰이 없는데 401 이면 로그인이 필요한 상황입니다
      // (own401 은 이 401 을 호출한 쪽이 직접 다루겠다는 뜻입니다)
      if (res.status === 401 && auth && !own401 && !getRefreshToken()) {
        notifySessionExpired();
        return toError('SESSION_EXPIRED');
      }

      // 액세스 토큰이 만료된 경우 → 한 번만 재발급 후 다시 시도
      if (res.status === 401 && auth && !noRetry && !own401 && !_retried && getRefreshToken()) {
        const again = await refresh();
        if (again.ok) return request(path, { ...opts, _retried: true });
        return toError('SESSION_EXPIRED');
      }

      if (!res.ok || json.success === false) {
        const code =
          err.code ||
          err.errorCode ||
          (statusMap && statusMap[res.status]) ||
          STATUS_FALLBACK[res.status] ||
          'UNKNOWN';

        const out = toError(code);
        // 서버가 사람이 읽을 문구를 주면 그걸 우선 보여줍니다
        if (err.message) out.text = err.message;
        out.status = res.status;
        return out;
      }

      // data 가 있으면 data 만, 없으면 전체를 돌려줍니다
      return { ok: true, data: json.data !== undefined && json.data !== null ? json.data : json };
    } catch (e) {
      // 무엇 때문에 실패했는지 콘솔에 남깁니다.
      // fetch 가 던지는 오류는 CORS 차단과 서버 다운을 구분해주지 않아서,
      // 개발자도구 Network 탭을 함께 보셔야 합니다. (server-check.html 참고)
      console.error(
        `[API] ${method} ${BASE_URL + path} 실패 —`,
        e && e.name === 'AbortError' ? '응답이 없어 시간 초과' : e && e.message,
        '\n서버가 떠 있는지 / CORS 가 열려 있는지 확인: ./server-check.html',
      );

      const out = toError('NETWORK_ERROR');

      /* 내 컴퓨터에서 개발 중일 때는 '인터넷을 확인하라'는 말이 맞지 않습니다.
         이 경우 실패 원인은 거의 항상 서버가 안 떴거나 CORS 로 막힌 것입니다. */
      if (DEV_HOST) {
        out.text =
          e && e.name === 'AbortError'
            ? '서버가 응답하지 않아요. 서버가 켜져 있는지 확인해 주세요.'
            : '서버에 연결하지 못했어요. server-check.html 로 확인해 보세요.';
      }
      return out;
    } finally {
      clearTimeout(timer);
    }
  }

  /* ---------- 토큰 보관 ----------
     주의: 브라우저 저장소 대신 메모리에 보관합니다.
     실제 서비스에서는 httpOnly 쿠키 사용을 권장합니다. */
  const getToken = () => Store.tokens().accessToken;
  const getRefreshToken = () => Store.tokens().refreshToken;

  function setTokens(accessToken, refreshToken, onboardingToken) {
    Store.saveTokens({
      accessToken,
      refreshToken,
      // 새로 주지 않으면 갖고 있던 값을 유지합니다
      onboardingToken:
        onboardingToken !== undefined ? onboardingToken : Store.tokens().onboardingToken,
    });
  }
  const getOnboardingToken = () => Store.tokens().onboardingToken || null;
  const clearToken = () => Store.saveTokens(null);

  const delay = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------- 목 데이터 ---------- */

  /* ============================================
     화면에서 호출하는 함수들
     ============================================ */

  /** 로그인 — 성공: {ok:true, data:{token, user}} / 실패: {ok:false, code, field, text} */
  async function login({ userId, password }) {
    if (live('login')) {
      const res = await request('/auth/login', {
        method: 'POST',
        auth: false,
        body: { loginId: userId, password },
        statusMap: {
          400: 'INVALID_CREDENTIALS', // 아이디 또는 비번 틀림 / 값 누락
          409: 'WITHDRAWN_USER', // 이미 탈퇴한 회원
        },
      });
      if (!res.ok) return res;

      // onboardingToken 은 지금 응답에 없지만, 생기면 그대로 받아 둡니다 (2.1 에서 씀)
      setTokens(res.data.accessToken, res.data.refreshToken, res.data.onboardingToken);

      // 이 기기의 프로필 자리를 열고, 서버 값으로 맞춥니다(1.6)
      Store.signIn(userId);
      Store.hydrate(res.data);
      await syncProfile(); // 실패해도 로그인은 그대로 둡니다
      return res;
    }

    await delay(120);

    // 목 모드에서는 서버 없이 그대로 통과시킵니다 (화면 확인용)
    setTokens('mock-token', 'mock-refresh');
    const { user } = Store.signIn(userId);
    return { ok: true, data: { token: 'mock-token', user: user.profile } };
  }

  /* ============================================================
     카카오 로그인 (1.2-1)
     ============================================================ */

  /* ↓↓↓ 카카오 개발자센터 > 내 애플리케이션 > 앱 키 > REST API 키 를 붙여넣으세요 ↓↓↓ */
  const KAKAO_CLIENT_ID = '';

  /* 비워두면 지금 열려 있는 주소 기준으로 자동으로 만듭니다.
     카카오에 등록한 Redirect URI 와 '글자 하나까지' 같아야 합니다.
     다르면 카카오가 KOE006 을 돌려줍니다. */
  const KAKAO_REDIRECT_URI = '';

  function kakaoRedirectUri() {
    if (KAKAO_REDIRECT_URI) return KAKAO_REDIRECT_URI;
    const dir = location.pathname.replace(/[^/]*$/, '');
    return location.origin + dir + 'kakao-callback.html';
  }

  /* 카카오 로그인 화면 주소 — 이 주소로 보내면 카카오가 code 를 붙여 돌려보냅니다 */
  function kakaoAuthUrl() {
    if (!KAKAO_CLIENT_ID) return null;
    const q = new URLSearchParams({
      client_id: KAKAO_CLIENT_ID,
      redirect_uri: kakaoRedirectUri(),
      response_type: 'code',
    });
    return 'https://kauth.kakao.com/oauth/authorize?' + q;
  }

  /* JWT 안의 sub(사용자 번호)를 꺼냅니다.
     카카오 로그인은 아이디가 없어서, 이 값을 기기 안 계정 구분에 씁니다. */
  function subOfToken(jwt) {
    try {
      const part = String(jwt).split('.')[1];
      const json = JSON.parse(
        decodeURIComponent(
          atob(part.replace(/-/g, '+').replace(/_/g, '/'))
            .split('')
            .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
            .join(''),
        ),
      );
      return json.sub || json.userId || json.id || null;
    } catch (e) {
      return null;
    }
  }

  /**
   * 카카오 로그인
   *   POST /api/auth/kakao
   *   요청  { code, redirectUri }
   *   응답  200 { token, refreshToken, user:{nickname}, isNewUser, onboardingToken }
   *         401 카카오 인증 실패 (code 만료·불일치)
   *         409 이미 탈퇴한 회원 / 500 서버 오류
   *
   * 응답이 두 갈래입니다.
   *   기존 회원  token 이 있음        → 바로 로그인 완료
   *   신규 회원  token 이 null,
   *              onboardingToken 발급 → 온보딩을 받고 kakaoComplete 로 마무리
   *
   * 주의: 액세스 토큰 이름이 `token` 입니다 (아이디 로그인은 `accessToken`).
   */
  async function kakaoLogin({ code, redirectUri }) {
    if (!live('kakao')) {
      await delay(120);
      setTokens('mock-token', 'mock-refresh');
      const { user } = Store.signIn('kakao_mock');
      return {
        ok: true,
        data: { needsOnboarding: false, nickname: user.profile.nickname },
      };
    }

    const res = await request('/auth/kakao', {
      method: 'POST',
      auth: false,
      body: { code, redirectUri: redirectUri || kakaoRedirectUri() },
      statusMap: {
        401: 'KAKAO_AUTH_FAILED',
        409: 'WITHDRAWN_USER',
      },
    });
    if (!res.ok) return res;

    const out = applyKakaoResult(res.data);
    if (!out.needsOnboarding) await syncProfile();
    return { ok: true, data: out };
  }

  /* 카카오 응답(로그인/온보딩 완료 공통)을 받아 세션을 정리합니다 */
  function applyKakaoResult(data) {
    const nickname = (data.user && data.user.nickname) || '';

    /* 아직 온보딩이 남은 경우 — 토큰은 안 주고 onboardingToken 만 옵니다 (10분) */
    if (!data.token) {
      Store.saveTokens({
        accessToken: null,
        refreshToken: null,
        onboardingToken: data.onboardingToken || null,
      });
      return {
        needsOnboarding: true,
        nickname,
        onboardingToken: data.onboardingToken || null,
      };
    }

    /* 로그인 완료 */
    setTokens(data.token, data.refreshToken, null);

    const accountId = 'kakao:' + (subOfToken(data.token) || nickname || 'user');
    Store.signIn(accountId);
    if (nickname) Store.updateProfile({ nickname });

    return { needsOnboarding: false, nickname, accountId };
  }

  /**
   * 카카오 온보딩 마무리 — 토큰 발급 (1.2-2)
   *   POST /api/auth/kakao/complete
   *   요청  { onboardingToken }   — 1.2-1 에서 받은 값 그대로 (10분 유효)
   *   응답  200 1.2-1 과 같은 구조. 보통 token 이 들어옵니다.
   *         401 onboardingToken 만료·무효 / 404 토큰 속 사용자 없음
   *         409 이미 탈퇴한 회원 / 500 서버 오류
   *
   * 주의: 200 인데도 아직 온보딩이 안 끝난 경우가 있습니다.
   *      그때는 isNewUser:true 로 오고 onboardingToken 이 새로 발급됩니다.
   *      (applyKakaoResult 가 새 토큰을 받아 두므로 다시 시도할 수 있습니다)
   */
  async function kakaoComplete() {
    const token = getOnboardingToken();

    if (!live('kakao')) {
      await delay(80);
      setTokens('mock-token', 'mock-refresh', null);
      return { ok: true, data: { needsOnboarding: false, nickname: '' } };
    }

    if (!token) return toError('ONBOARDING_TOKEN_EXPIRED');

    const res = await request('/auth/kakao/complete', {
      method: 'POST',
      auth: false,
      body: { onboardingToken: token },
      own401: true,
      statusMap: {
        401: 'ONBOARDING_TOKEN_EXPIRED',
        404: 'ONBOARDING_USER_NOT_FOUND',
        409: 'WITHDRAWN_USER',
      },
    });
    if (!res.ok) return res;

    const out = applyKakaoResult(res.data);
    if (!out.needsOnboarding) await syncProfile();
    return { ok: true, data: out };
  }

  /**
   * 회원가입
   *   POST /api/auth/signup
   *   요청  { loginId, password, email, name, nickname }
   *   응답  201 { success:true, data:{ userId:5 }, error:null }
   *         400 필수 값 누락·형식 오류 / 409 이미 등록된 이메일 / 500 서버 오류
   *
   * 서버가 토큰을 주지 않으므로, 가입 성공 후 곧바로 로그인해 세션을 만듭니다.
   */
  async function signup(payload) {
    if (live('signup')) {
      const res = await request('/auth/signup', {
        method: 'POST',
        auth: false,
        body: {
          loginId: payload.userId,
          password: payload.password,
          email: payload.email,
          name: payload.name,
          nickname: payload.nickname,
        },
        statusMap: { 409: 'DUPLICATE_EMAIL', 400: 'INVALID_INPUT' },
      });
      if (!res.ok) return res;

      // 가입 성공 → 이 기기에 프로필 자리를 만듭니다 (비밀번호는 저장 안 함)
      Store.createProfile(payload.userId, {
        name: payload.name,
        nickname: payload.nickname,
        email: payload.email,
        serverId: res.data.userId,
      });

      // 로그인 API 가 준비되면 토큰까지 받아옵니다.
      // 아직이면 방금 만든 로컬 세션으로 그대로 진행합니다.
      if (live('login')) {
        const signed = await login({
          userId: payload.userId,
          password: payload.password,
        });
        if (!signed.ok) return signed;
      }
      return { ok: true, data: res.data };
    }

    await delay(150);

    setTokens('mock-token', 'mock-refresh');
    Store.createProfile(payload.userId, payload);
    return { ok: true, data: { token: 'mock-token', userId: payload.userId } };
  }

  /** 중복 확인 — field: 'userId' | 'nickname' | 'email' */
  /**
   * 내 정보 조회 (1.6)
   *   GET /api/users/me
   *   응답  200 { userId, nickname, profileImageUrl, pointBalance,
   *              interestCategories:[...], ageGroup, gender, createdAt }
   *         401 인증 / 500 서버 오류
   *
   * 로그인 직후에 한 번 불러 이 기기의 프로필을 서버 값으로 맞춥니다.
   * 그래야 다른 기기에서 봐도 닉네임·관심분야·포인트가 같습니다.
   */
  async function getMe(opts = {}) {
    if (!live('profile')) {
      await delay(60);
      const u = Store.current();
      if (!u) return toError('SESSION_EXPIRED');
      return {
        ok: true,
        data: {
          userId: u.profile.userId,
          nickname: u.profile.nickname,
          pointBalance: Store.totalPoint(),
          interests: u.profile.interests || [],
          ageRange: u.profile.ageRange || null,
          gender: u.profile.gender || null,
        },
      };
    }

    /* quiet 로 부르면 401 이 와도 세션을 건드리지 않습니다.
       로그인 직후 프로필을 맞추는 용도라, 이것 때문에 로그아웃되면 안 됩니다. */
    const res = await request('/users/me', opts.quiet ? { own401: true } : {});
    if (!res.ok) return res;

    const d = res.data;
    return {
      ok: true,
      data: {
        userId: d.userId,
        nickname: d.nickname || '',
        profileImageUrl: d.profileImageUrl || null,
        pointBalance: Number(d.pointBalance) || 0,
        /* 서버 enum → 화면 문구.
           지금 서버의 1.6 응답에는 interestCategories 가 아예 없습니다.
           없는 것을 빈 배열로 만들면 화면에 저장돼 있던 관심분야가 지워지므로
           (관심분야 변경 화면이 매번 빈 상태로 열리는 원인이었습니다)
           안 왔을 때는 undefined 로 두어 '건드리지 않음'이 되게 합니다. */
        interests: Array.isArray(d.interestCategories)
          ? d.interestCategories.map((v) => valueToLabel(INTEREST_OPTIONS, v))
          : undefined,
        ageRange: ageLabelOf(d.ageGroup),
        gender: d.gender ? valueToLabel(GENDER_OPTIONS, d.gender) : null,
        createdAt: d.createdAt || null,
      },
    };
  }

  /**
   * 내 정보 수정 (1.7)
   *   PATCH /api/users/me/nickname
   *   요청  { nickname?, profileImageUrl? }  — 바꿀 것만
   *   응답  200 { userId, nickname, profileImageUrl }
   *         400 요청 값 오류 / 401 인증 / 500 서버 오류
   *
   * 프로필 사진은 고르는 기능을 뺐으므로 지금은 닉네임만 보냅니다.
   */
  async function updateMe(patch = {}) {
    const body = {};
    if (patch.nickname !== undefined) body.nickname = patch.nickname;
    if (patch.profileImageUrl !== undefined) body.profileImageUrl = patch.profileImageUrl;

    if (!Object.keys(body).length) return toError('INVALID_INPUT');

    if (!live('profile')) {
      await delay(80);
      Store.updateProfile(body);
      return { ok: true, data: body };
    }

    const res = await request('/users/me/nickname', {
      method: 'PATCH',
      body,
      /* 형식은 화면에서 이미 확인했으니, 여기서의 400 은
         대개 '이미 쓰는 닉네임'입니다. 그래서 닉네임 칸에 표시합니다. */
      statusMap: { 400: 'NICKNAME_REJECTED' },
    });
    if (!res.ok) return res;

    // 서버가 확정한 값으로 맞춥니다
    Store.updateProfile({
      nickname: res.data.nickname || body.nickname,
    });
    return res;
  }

  /**
   * 로그인 직후 프로필 맞추기
   * 실패해도 로그인은 유지합니다 — 이것 때문에 못 들어가면 안 되니까요.
   */
  async function syncProfile() {
    const res = await getMe({ quiet: true });
    if (!res.ok) return res;

    /* 값이 온 항목만 덮어씁니다.
       undefined 를 그대로 넣으면 기존 값이 지워집니다. */
    const d = res.data;
    const patch = {};
    if (d.nickname) patch.nickname = d.nickname;
    if (d.ageRange) patch.ageRange = d.ageRange;
    if (d.gender) patch.gender = d.gender;
    if (Array.isArray(d.interests)) {
      patch.interests = d.interests;
      patch.onboardingCompleted = d.interests.length > 0;
    }

    Store.updateProfile(patch);
    return res;
  }

  /**
   * 중복 확인 — 서버 API 가 아직 없습니다.
   * 지금은 통과시키고, 실제 중복은 가입할 때 409 로 걸러집니다.
   */
  async function checkDuplicate(field, value) {
    if (live('checkDuplicate')) {
      return request(
        `/auth/check?field=${encodeURIComponent(field)}&value=${encodeURIComponent(value)}`,
        { auth: false },
      );
    }
    return { ok: true, data: { available: true } };
  }

  /* ---------- 판정 ----------
     엔드포인트 경로는 아래 한 줄에서 바꿀 수 있습니다. */
  const JUDGE_PATH = '/judgments'; // 서버는 e 없는 /judgments 입니다 (2026.08.19 확인)

  /* 공유 링크만 명세서 URL 이 /judgments (e 없음) 로 적혀 있습니다.
     서버와 다르면 404 가 나니 이 줄을 고치면 됩니다. */
  const SHARE_PATH = '/judgments';

  /**
   * 판정 요청 생성
   *   POST /api/judgements
   *   요청  { inputType:'TEXT'|'IMAGE'|'LINK', text, imageBase64, url, categoryId }
   *   응답  202 { success:true, data:{ judgmentId:1, status:'PROCESSING' } }
   *
   * 비동기라서 접수만 하고 끝납니다. 상세 결과는 조회 API 로 따로 받아옵니다.
   *
   *   400 입력 값 오류
   *   401 인증 필요·토큰 만료
   *   422 입력 형식 인식 불가 (OCR·자막 추출 실패) → 추출 실패 안내 화면
   *   429 일일 한도 초과 (nextAvailableAt 포함) → 한도 초과 안내 화면
   *   500 서버 오류
   */
  let mockCount = 0;
  const DAILY_MAX = 3; // 목 모드 하루 한도 (모달 확인용)

  async function requestJudge(payload) {
    if (live('judge')) {
      const body = { inputType: (payload.type || 'text').toUpperCase() };

      if (body.inputType === 'TEXT') body.text = payload.text;
      if (body.inputType === 'IMAGE') body.imageBase64 = payload.imageBase64;
      if (body.inputType === 'LINK') body.url = payload.url;
      if (payload.categoryId) body.categoryId = payload.categoryId;

      const res = await request(JUDGE_PATH, {
        method: 'POST',
        body,
        statusMap: {
          400: 'INVALID_INPUT',
          422: 'OCR_FAILED',
          429: 'DAILY_LIMIT',
        },
      });
      if (!res.ok) return res;

      // 접수만 된 상태 — 결과는 조회 API 로 받아옵니다
      const id = String(res.data.judgmentId);
      Store.saveResult({
        id,
        claim: payload.text || payload.url || payload.fileName || '판정 요청',
        type: payload.type,
        status: res.data.status || 'PROCESSING',
        createdAt: new Date().toISOString(),
      });
      return { ok: true, data: { ...res.data, id } };
    }

    await delay(300);

    // 목 모드에서 추출 실패 화면을 보려면
    //   이미지: 파일명에 fail 포함  /  링크: 주소에 fail 포함
    const name = payload.fileName || payload.url || '';
    if (payload.type !== 'text' && /fail/i.test(name)) {
      return toError('OCR_FAILED');
    }

    if (mockCount >= DAILY_MAX) return toError('DAILY_LIMIT');
    mockCount += 1;

    // 입력한 내용을 그대로 판정 대상으로 삼습니다.
    const claim = payload.text || payload.url || payload.fileName || '판정 요청';

    // 같은 문장은 늘 같은 결과가 나오도록 내용에서 등급을 계산합니다.
    const levels =
      typeof EVIDENCE_LEVELS !== 'undefined'
        ? EVIDENCE_LEVELS
        : [{ key: 'hold' }];
    const level = levels[Store.hashOf(claim) % levels.length];

    const result = {
      id: 'j' + Date.now(),
      claim,
      type: payload.type,
      level: level.key,
      conflict: Store.hashOf(claim) % 2 === 0,
      createdAt: new Date().toISOString(),
    };
    Store.saveResult(result);

    Store.markJudged(result.id);
    return { ok: true, data: result };
  }

  /* ---------- 서버 값 → 화면 값 ---------- */
  const TRUST_TO_LEVEL = {
    CLINICAL_EVIDENCE: 'clinical',
    EXPERT_OPINION: 'expert',
    PENDING: 'hold',
    NO_EVIDENCE: 'lack',
    COUNTER_EVIDENCE: 'refuted',
  };
  function normalizeJudgment(d) {
    const coi = d.conflictOfInterest || {};
    return {
      id: String(d.judgmentId),
      status: d.status,
      claim: d.extractedText || '',
      inputType: d.inputType,
      categoryId: d.categoryId,
      level: TRUST_TO_LEVEL[d.trustLevel] || null,
      levelLabel: d.trustLevelLabel || null,
      evidence: d.evidenceSummary || '',
      conflict: Boolean(coi.detected),
      conflictType: coi.type || null,
      conflictBadge: coi.badgeLabel || '이해상충 가능성',
      conflictDesc: coi.description || '',
      safetyNotice: d.safetyNotice || null,
      sources: Array.isArray(d.sources) ? d.sources : [],
      guideCard: d.guideCard || null,
      createdAt: d.createdAt,
    };
  }

  /**
   * 판정 결과 조회
   *   GET /api/judgements/{judgementId}
   *   200 조회 성공 / 401 인증 / 403 남의 판정 / 404 없음 / 500 서버 오류
   */
  async function getJudgment(id) {
    if (!live('judge')) {
      const saved = Store.getResult(String(id));
      return saved
        ? { ok: true, data: { ...saved, status: saved.status || 'DONE' } }
        : toError('NOT_FOUND');
    }

    const res = await request(`${JUDGE_PATH}/${encodeURIComponent(id)}`, {
      statusMap: { 403: 'FORBIDDEN', 404: 'NOT_FOUND' },
    });
    if (!res.ok) return res;

    const result = normalizeJudgment(res.data);
    Store.saveResult(result);

    // 판정이 끝나면 포인트를 한 번만 줍니다 (이력 목록은 서버에서 받습니다)
    if (result.status === 'DONE') Store.markJudged(result.id);
    return { ok: true, data: result };
  }

  /* 라벨 문자열 → 이력 뱃지 상태 */
  const LABEL_TO_HISTORY = {
    '임상적 근거 있음': 'fit',
    '전문가 의견 있음': 'fit',
    판단보류: 'vague',
    '근거 부족': 'vague',
    '반박 근거 있음': 'unfit',
  };

  /**
   * 판정 히스토리 조회
   *   GET /api/judgements?page=&size=&categoryId=
   *   응답 200 { success:true, data:{ items:[...], hasNext:true } }
   *        401 인증 / 500 서버 오류
   *
   * items 에는 제목이 없어서, 이 기기에 저장된 판정 문장이 있으면 함께 채웁니다.
   */
  async function getJudgmentHistory(opts = {}) {
    const page = opts.page || 1;
    const size = opts.size || 20;

    if (!live('judge')) {
      const u = Store.current();
      const all = u ? u.history : [];
      const start = (page - 1) * size;
      return {
        ok: true,
        data: { items: all.slice(start, start + size), hasNext: all.length > start + size },
      };
    }

    const q = new URLSearchParams({ page: String(page), size: String(size) });
    if (opts.categoryId) q.set('categoryId', String(opts.categoryId));

    const res = await request(`${JUDGE_PATH}?${q}`);
    if (!res.ok) return res;

    const items = (res.data.items || []).map((it) => {
      const saved = Store.getResult(String(it.judgmentId));
      const title = (saved && saved.claim) || `판정 #${it.judgmentId}`;
      return {
        id: String(it.judgmentId),
        title: title.length > 24 ? title.slice(0, 24) + '…' : title,
        category: it.trustLevelLabel || '기타',
        categoryId: it.categoryId,
        status: LABEL_TO_HISTORY[it.trustLevelLabel] || 'vague',
        at: formatDate(it.createdAt),
      };
    });

    return { ok: true, data: { items, hasNext: Boolean(res.data.hasNext) } };
  }

  function formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return String(iso);
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())} · ${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  /**
   * 판정이 끝날 때까지 기다립니다.
   * PROCESSING 이면 잠깐 쉬었다가 다시 물어봅니다.
   */
  async function waitForJudgment(id, opts = {}) {
    const interval = opts.interval || 1500;
    const timeout = opts.timeout || 60000;
    const onTick = opts.onTick;
    const started = Date.now();

    while (Date.now() - started < timeout) {
      const res = await getJudgment(id);
      if (!res.ok) return res;

      if (res.data.status !== 'PROCESSING') return res;
      if (onTick) onTick(res.data);

      await delay(interval);
    }
    return toError('JUDGE_TIMEOUT');
  }

  /* ---------- 온보딩 ----------
     화면에서는 한글 라벨을 쓰고, 여기서 서버 값으로 바꿔 보냅니다.
     값이 주어진 항목만 담습니다(수정 때 일부만 보내기 위함). */
  /* 관심 카테고리를 담는 필드 이름이 저장(2.1)과 수정(2.2) 명세에서 다릅니다.
     둘 다 같은 이름이라고 확인되면 아래 한 줄만 맞추면 됩니다. */
  /* POST·PATCH 둘 다 interestCategoryCodes 입니다.
     interestCategories 로 보내면 서버가 200 을 주면서도 관심분야를 저장하지 않습니다
     (오류가 안 나서 못 알아챕니다 — 2026.08.19 실측). */
  const INTEREST_FIELD = {
    POST: 'interestCategoryCodes',
    PATCH: 'interestCategoryCodes',
  };

  /* 온보딩 경로 — 백엔드가 /me/onboarding 에서 여기로 옮겼습니다.
     옛 경로로 부르면 500 (No static resource) 이 옵니다. */
  const ONBOARDING_PATH = '/users/me/onboarding';

  function onboardingBody({ interests, ageRange, gender }, method) {
    const body = {};
    if (interests) {
      body[INTEREST_FIELD[method] || 'interestCategoryCodes'] = interests
        .map((l) => labelToValue(INTEREST_OPTIONS, l))
        .filter(Boolean);
    }
    if (ageRange) body.ageGroup = labelToValue(AGE_OPTIONS, ageRange);
    if (gender) body.gender = labelToValue(GENDER_OPTIONS, gender);
    return body;
  }

  function applyOnboarding(input, data) {
    const patch = {};
    if (input.interests) patch.interests = input.interests;
    if (input.ageRange) patch.ageRange = input.ageRange;
    if (input.gender) patch.gender = input.gender;
    if (data && data.onboardingCompleted !== undefined) {
      patch.onboardingCompleted = Boolean(data.onboardingCompleted);
    }
    Store.updateProfile(patch);
  }

  /**
   * 온보딩 정보 저장 (최초)
   *   POST /api/me/onboarding
   *   요청  { onboardingToken?, interestCategoryCodes:[...], ageGroup, gender }
   *   응답  201 { interestCategories:[...], ageGroup, gender, onboardingCompleted:true }
   *         400 필수 값 누락·형식 오류·카테고리 코드 오류
   *         401 onboardingToken 만료 / 404 토큰 속 사용자 없음 / 500 서버 오류
   *
   * onboardingToken 은 카카오 로그인 응답에서 받는 값입니다.
   * 지금은 카카오를 쓰지 않아 값이 없으므로, 있을 때만 담고
   * 없으면 로그인한 사람의 Authorization 헤더로 본인을 확인합니다.
   */
  async function saveOnboarding(input) {
    const token = getOnboardingToken();

    /* 서버의 POST 는 onboardingToken 을 '필수'로 요구합니다.
       그 토큰은 카카오 로그인에서만 나오므로, 아이디·비밀번호로 가입한 사람은
       POST 를 쓸 수가 없습니다(400 onboardingToken 은 필수입니다).
       PATCH 는 Authorization 헤더만으로 통과하고 결과도 같습니다
       — onboardingCompleted 까지 true 로 옵니다 (2026.08.19 실측). */
    const method = token ? 'POST' : 'PATCH';
    const body = onboardingBody(input, method);
    if (token) body.onboardingToken = token;

    if (live('onboarding')) {
      const res = await request(ONBOARDING_PATH, {
        method,
        body,
        // onboardingToken 을 보낸 경우의 401 은 그 토큰이 만료된 것이라
        // 액세스 토큰 재발급으로는 해결되지 않습니다. 그래서 재시도하지 않습니다.
        own401: Boolean(token),
        statusMap: {
          400: 'INVALID_INPUT',
          401: token ? 'ONBOARDING_TOKEN_EXPIRED' : undefined,
          404: 'ONBOARDING_USER_NOT_FOUND',
        },
      });
      if (!res.ok) return res;

      /* onboardingToken 은 여기서 지우지 않습니다.
         카카오 흐름에서는 온보딩 저장 뒤 /auth/kakao/complete 에 한 번 더 필요합니다.
         (거기서 진짜 토큰을 받을 때 함께 비워집니다) */

      applyOnboarding(input, res.data);
      return res;
    }

    await delay(80);
    applyOnboarding(input, { onboardingCompleted: true });
    return { ok: true, data: { ...body, onboardingCompleted: true } };
  }

  /**
   * 온보딩 정보 수정
   *   PATCH /api/me/onboarding
   *   요청  { interestCategories?, ageGroup?, gender? }  — 바꿀 것만
   *   응답  200 (2.1 과 같은 구조, 수정된 값 반영)
   *
   * 아직 최초 저장 전이면 POST 로 돌립니다.
   */
  async function updateOnboarding(input) {
    const me = Store.current();
    if (!me || !me.profile.onboardingCompleted) return saveOnboarding(input);

    const body = onboardingBody(input, 'PATCH');

    if (live('onboarding')) {
      const res = await request(ONBOARDING_PATH, {
        method: 'PATCH',
        body,
        statusMap: { 400: 'INVALID_INPUT' },
      });
      if (!res.ok) return res;
      applyOnboarding(input, res.data);
      return res;
    }

    await delay(80);
    applyOnboarding(input, null);
    return { ok: true, data: body };
  }

  /**
   * 판정 결과 공유 링크 생성
   *   POST /api/judgments/{judgmentId}/share
   *   응답  201 { success:true, data:{ shareToken, shareUrl, imageUrl } }
   *         401 인증 / 403 남의 판정 / 404 없음 / 500 서버 오류
   */
  async function createShareLink(judgmentId) {
    if (!live('share')) {
      await delay(80);
      return {
        ok: true,
        data: {
          shareToken: 'mock-token',
          shareUrl: location.href,
          imageUrl: null,
        },
      };
    }

    return request(`${SHARE_PATH}/${encodeURIComponent(judgmentId)}/share`, {
      method: 'POST',
      statusMap: { 403: 'FORBIDDEN', 404: 'NOT_FOUND' },
    });
  }

  /**
   * 공유 피드에 게시
   *   POST /api/feed/posts
   *   요청  { judgmentId }
   *   응답  201 { success:true, data:{ postId:'p_5001', status:'PUBLISHED' } }
   *         400 검증되지 않은 판정 등 게시 불가 / 401 인증 / 404 판정 없음 / 500 서버 오류
   */
  async function publishToFeed(judgmentId) {
    if (!live('feed')) {
      await delay(80);
      return { ok: true, data: { postId: 'p_' + Date.now(), status: 'PUBLISHED' } };
    }

    return request('/feed/posts', {
      method: 'POST',
      body: { judgmentId: String(judgmentId) },
      statusMap: { 400: 'FEED_BLOCKED', 404: 'NOT_FOUND' },
    });
  }

  /* 라벨 → 피드 카드의 판정 결과 줄 */
  /* 서버가 주는 라벨 문구 → data.js 의 5단계 키.
     아이콘·안내 문구(EVIDENCE_LEVELS)를 그대로 쓰기 위해 정확히 맞춥니다. */
  const LABEL_TO_RESULT = {
    '임상적 근거 있음': 'clinical',
    '전문가 의견 있음': 'expert',
    판단보류: 'hold',
    '근거 부족': 'lack',
    '반박 근거 있음': 'refuted',
  };

  /**
   * 공유 피드 전체 목록 조회
   *   GET /api/feed/posts/me?page=&size=   ← 서버에 전체 목록 API 가 없어 '내 게시물'을 씁니다
   *   sort  recent | popular (기본 recent) — 서버 미지원이라 받아온 뒤 화면에서 정렬합니다
   *   응답  200 { items:[{ postId, author:{userId,nickname}, trustLevelLabel,
   *              summary, likeCount, createdAt }], page, totalPages }
   *         401 인증 / 500 서버 오류
   */
  async function getFeedPosts(opts = {}) {
    const sort = opts.sort === 'popular' ? 'popular' : 'recent';
    const page = opts.page || 1;
    const size = opts.size || 20;

    if (!live('feed')) {
      await delay(80);
      const all = typeof FEED_CARDS !== 'undefined' ? FEED_CARDS : [];
      return { ok: true, data: { items: all, page: 1, totalPages: 1 } };
    }

    /* 서버에는 '전체 피드' 목록 API 가 없습니다. 있는 것은 내 게시물뿐이라
       (GET /feed/posts/me) 그쪽을 씁니다. /feed/posts 로 부르면 500 이 옵니다.
       전체 피드 API 가 생기면 이 두 줄만 되돌리면 됩니다. */
    const q = new URLSearchParams({ page: String(page), size: String(size) });
    const res = await request(`/feed/posts/me?${q}`);
    if (!res.ok) return res;

    /* 목록에 title·category 가 없어서(6.5), 이 기기에서 올린 글이면
       그때 저장해 둔 원문을 대신 보여 줍니다. */
    const mine = (Store.current() || { cards: [] }).cards;

    /* 서버가 sort 파라미터를 받지 않아 여기서 정렬합니다 */
    const raw = (res.data.items || []).slice();
    raw.sort((a, b) =>
      sort === 'popular'
        ? (b.likeCount || 0) - (a.likeCount || 0)
        : String(b.createdAt || '').localeCompare(String(a.createdAt || '')),
    );

    return {
      ok: true,
      data: {
        page: res.data.page || page,
        totalPages: res.data.totalPages || 1,
        items: raw.map((it) => {
          const local = mine.find((c) => c.postId === it.postId) || {};
          const title = it.title || local.title || it.summary || '';
          return {
            id: it.postId,
            author: (it.author && it.author.nickname) || '익명',
            authorId: it.author && it.author.userId,
            category: it.category || it.categoryName || local.category || '',
            title,
            /* title 이 summary 로 대체된 경우엔 설명을 비워 둡니다 (같은 문장 두 번 노출 방지) */
            desc: title === it.summary ? '' : it.summary || '',
            levelLabel: it.trustLevelLabel || '',
            result: LABEL_TO_RESULT[it.trustLevelLabel] || 'hold',
            summary: it.summary || '',
            likes: it.likeCount || 0,
            liked: Boolean(it.liked), // 서버가 안 주면 false 로 시작합니다
            createdAt: it.createdAt,
          };
        }),
      },
    };
  }

  /**
   * 피드 게시물 좋아요 / 좋아요 취소
   *   좋아요   POST   /api/feed/posts/{postId}/like
   *   취소     DELETE /api/feed/posts/{postId}/like
   *   응답  200 { success:true, data:{ liked:true, likeCount:13 } }
   *         401 인증 / 404 게시물 없음 / 500 서버 오류
   *
   * @param {string}  postId
   * @param {boolean} liked  지금 눌러져 있는지 (true 면 취소로 보냅니다)
   */
  async function toggleLike(postId, liked) {
    const method = liked ? 'DELETE' : 'POST';

    if (!live('feed')) {
      await delay(80);
      return { ok: true, data: { liked: !liked, likeCount: liked ? 0 : 1 } };
    }

    return request(`/feed/posts/${encodeURIComponent(postId)}/like`, {
      method,
      statusMap: { 404: 'NOT_FOUND' },
    });
  }

  /**
   * 피드 게시물 삭제 (본인 것만)
   *   DELETE /api/feed/posts/{postId}
   *   응답  200 { success:true, data:null }
   *         401 인증 / 403 남의 글 / 404 없음 / 500 서버 오류
   */
  async function deletePost(postId) {
    if (!live('feed')) {
      await delay(80);
      return { ok: true, data: null };
    }

    return request(`/feed/posts/${encodeURIComponent(postId)}`, {
      method: 'DELETE',
      statusMap: { 403: 'FORBIDDEN', 404: 'NOT_FOUND' },
    });
  }

  /**
   * 내가 올린 피드 게시물 목록
   *   GET /api/feed/posts/me?page=&size=
   *   응답  200 6.5 와 같은 구조, 본인 게시물만
   *         401 인증 / 500 서버 오류
   *
   * 삭제는 postId 로 하므로(6.8) 별도 보정이 필요 없습니다.
   * 제목만, 이 기기에서 올린 글이면 원문을 대신 보여줍니다.
   */
  async function getMyFeedPosts(opts = {}) {
    const page = opts.page || 1;
    const size = opts.size || 20;

    if (!live('feed')) {
      await delay(80);
      const u = Store.current();
      return {
        ok: true,
        data: { items: u ? u.cards : [], page: 1, totalPages: 1 },
      };
    }

    const q = new URLSearchParams({ page: String(page), size: String(size) });
    const res = await request(`/feed/posts/me?${q}`);
    if (!res.ok) return res;

    const mine = (Store.current() || { cards: [] }).cards;

    return {
      ok: true,
      data: {
        page: res.data.page || page,
        totalPages: res.data.totalPages || 1,
        items: (res.data.items || []).map((it) => {
          const local = mine.find((c) => c.postId === it.postId) || {};
          return {
            id: it.postId,
            postId: it.postId,
            title: local.title || it.summary || '',
            category: local.category || it.trustLevelLabel || '',
            date: formatDate(it.createdAt).split(' · ')[0],
            result: it.trustLevelLabel || '',
            likes: it.likeCount || 0,
          };
        }),
      },
    };
  }

  /* ============================================================
     7. 포인트
     ============================================================ */

  /**
   * 포인트 적립/사용 내역
   *   GET /api/users/me/points/history?page=&size=
   *   응답  200 { items:[{ type, reason, amount, createdAt }], page, totalPages }
   *         401 인증 필요/토큰 만료 · 500 서버 오류
   *
   *   type    EARN(적립) / USE(사용)
   *   reason  DAILY_LOGIN, FEED_POST … (문구는 data.js 의 POINT_REASON)
   *   amount  양수로 오고, 더할지 뺄지는 type 으로 판단합니다.
   */
  async function getPointHistory(opts = {}) {
    const page = Number(opts.page) || 1;
    const size = Number(opts.size) || 20;

    if (!live('points')) {
      await delay(80);
      const mine = (Store.current() || { points: [] }).points;
      return {
        ok: true,
        data: {
          page: 1,
          totalPages: 1,
          hasNext: false,
          items: mine.map((p) =>
            normalizePoint({
              type: 'EARN',
              reason: p.label,
              amount: p.amount,
              createdAt: p.at,
            }),
          ),
        },
      };
    }

    const q = new URLSearchParams({ page: String(page), size: String(size) });
    const res = await request(`/users/me/points/history?${q}`);
    if (!res.ok) return res;

    const cur = Number(res.data.page) || page;
    const total = Number(res.data.totalPages) || 1;

    return {
      ok: true,
      data: {
        page: cur,
        totalPages: total,
        hasNext: cur < total,
        items: (res.data.items || []).map(normalizePoint),
      },
    };
  }

  /* 서버 코드(FEED_POST 등)를 화면에 쓸 문구로 바꿔 줍니다. */
  function normalizePoint(it) {
    const used = String(it.type || 'EARN').toUpperCase() === 'USE';
    const amount = Math.abs(Number(it.amount) || 0);
    const code = it.reason == null ? '' : String(it.reason);

    /* 아직 모르는 코드가 오면 대문자 코드는 감추고 기본 문구를 씁니다.
       (한글 등 이미 사람이 읽을 수 있는 값이면 그대로 보여 줍니다.) */
    const known = typeof POINT_REASON !== 'undefined' ? POINT_REASON[code] : null;
    const readable = code && !/^[A-Z0-9_]+$/.test(code) ? code : '';
    const label = known || readable || (used ? '포인트 사용' : '포인트 적립');

    return {
      type: used ? 'USE' : 'EARN',
      reason: code,
      label,
      amount,
      signed: used ? -amount : amount,
      at: formatDate(it.createdAt),
      createdAt: it.createdAt || '',
    };
  }

  /**
   * 누적 포인트 + 전체 내역
   * 잔액만 주는 API 가 아직 없어서, 내역을 끝까지 훑어 더합니다.
   * 한 번에 100건씩 가져오고 최대 20페이지(2,000건)까지만 봅니다.
   * 거기서 끊기면 exact:false 로 알려 줍니다.
   */
  async function getPointSummary() {
    /* 잔액은 1.6(GET /users/me)이 정확히 줍니다. 그게 있으면 훑지 않습니다. */
    if (live('profile')) {
      const me = await getMe();
      if (!me.ok) return me;
      const first = await getPointHistory({ page: 1, size: 100 });
      if (!first.ok) return first;
      return {
        ok: true,
        data: {
          total: me.data.pointBalance,
          exact: true,
          items: first.data.items,
          hasMore: first.data.hasNext,
        },
      };
    }

    const MAX_PAGE = 20;
    const items = [];
    let total = 0;
    let page = 1;
    let pages = 1;
    let exact = true;

    while (page <= pages) {
      const res = await getPointHistory({ page, size: 100 });
      if (!res.ok) return res;

      res.data.items.forEach((p) => {
        items.push(p);
        total += p.signed;
      });

      pages = res.data.totalPages;
      if (page >= MAX_PAGE && page < pages) {
        exact = false;
        break;
      }
      page += 1;
    }

    return { ok: true, data: { total, exact, items } };
  }

  /**
   * 공유 링크 회수 (비활성화)
   *   DELETE /api/judgments/{judgmentId}/share
   *   응답  200 { success:true, data:null }
   *         401 인증 / 403 남의 판정 / 404 발급된 링크 없음 / 500 서버 오류
   *
   * 회수하면 그 링크로 들어온 사람은 410 을 받습니다.
   */
  async function revokeShareLink(judgmentId) {
    if (!live('share')) {
      await delay(80);
      return { ok: true, data: null };
    }

    return request(`${SHARE_PATH}/${encodeURIComponent(judgmentId)}/share`, {
      method: 'DELETE',
      statusMap: { 403: 'FORBIDDEN', 404: 'SHARE_NOT_FOUND' },
    });
  }

  /**
   * 공유 링크 공개 조회 (로그인 없이)
   *   GET /api/share/{shareToken}
   *   응답  200 3.2 와 같은 구조에서 작성자 정보 제외
   *         404 없는 링크 / 410 회수·만료된 링크 / 500 서버 오류
   */
  async function getSharedJudgment(shareToken) {
    if (!live('share')) {
      await delay(80);
      const saved = Store.getResult(String(shareToken));
      return saved ? { ok: true, data: saved } : toError('NOT_FOUND');
    }

    const res = await request(`/share/${encodeURIComponent(shareToken)}`, {
      auth: false, // 비회원도 볼 수 있는 링크입니다
      statusMap: { 404: 'NOT_FOUND', 410: 'SHARE_GONE' },
    });
    if (!res.ok) return res;

    return { ok: true, data: normalizeJudgment(res.data) };
  }

  /* ---------- 브리핑 ---------- */

  /* 4.1 / 4.2 응답은 필드 구조가 같아서 여기서 함께 정리합니다. */
  function normalizeBriefing(data, fallbackDate) {
    return {
      date: (data && data.date) || fallbackDate,
      items: ((data && data.items) || []).map((it) => ({
        id: it.briefingId,
        category: valueToLabel(INTEREST_OPTIONS, it.category),
        levelLabel: it.trustLevelLabel || '',
        title: it.title || '',
        summary: it.summary || '',
        archiveId: it.relatedArchiveId || null,
      })),
    };
  }

  /* 오늘 날짜(YYYY-MM-DD) — 반드시 그 사람의 시간대로 계산합니다.
     toISOString() 은 UTC 라서, 한국에서 자정~오전 9시 사이에는 어제가 나옵니다. */
  const todayIso = () => {
    const d = new Date();
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 10);
  };

  function mockBriefing(date) {
    return {
      ok: true,
      data: {
        date,
        items: (typeof FEEDS !== 'undefined' ? FEEDS : []).slice(0, 2).map((f) => ({
          id: f.id,
          category: f.category,
          levelLabel: '판단보류',
          title: f.title,
          summary: f.desc,
          archiveId: null,
        })),
      },
    };
  }

  /**
   * 오늘의 브리핑 조회
   *   GET /api/briefings/today
   *   응답  200 { success:true, data:{ date, items:[
   *              { briefingId, category, trustLevelLabel, title, summary, relatedArchiveId } ] } }
   *         401 인증 / 500 서버 오류
   *
   * 관심 카테고리와 판정 이력으로 매칭된 오늘의 카드 1~2건이 옵니다.
   */
  async function getTodayBriefing() {
    if (!live('briefing')) {
      await delay(80);
      return mockBriefing(todayIso());
    }

    const res = await request('/briefings/today');
    if (!res.ok) return res;

    return { ok: true, data: normalizeBriefing(res.data, todayIso()) };
  }

  /**
   * 특정 날짜 브리핑 조회
   *   GET /api/briefings/{date}      date 는 YYYY-MM-DD
   *   응답  200 4.1 과 같은 구조 (date 만 요청한 날짜)
   *         400 날짜 형식 오류 / 401 인증 / 404 그 날 브리핑 없음 / 500 서버 오류
   *
   * 오늘 날짜를 넣으면 4.1 로 돌립니다. 같은 내용을 두 경로로 부를 필요가 없어서입니다.
   */
  async function getBriefing(date) {
    const iso = String(date || '').slice(0, 10);

    // 서버에 보내기 전에 형식을 한 번 봅니다 (400 을 미리 막습니다)
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return toError('INVALID_DATE');
    if (iso === todayIso()) return getTodayBriefing();

    if (!live('briefing')) {
      await delay(80);
      return mockBriefing(iso);
    }

    const res = await request(`/briefings/${iso}`, {
      statusMap: { 400: 'INVALID_DATE', 404: 'BRIEFING_NOT_FOUND' },
    });
    if (!res.ok) return res;

    return { ok: true, data: normalizeBriefing(res.data, iso) };
  }

  /**
   * 브리핑 열람 기록 (오픈율 지표용)
   *   POST /api/briefings/{briefingId}/open
   *   응답  200 { success:true, data:{ opened:true } }
   *         401 인증 / 404 해당 브리핑 없음 / 500 서버 오류
   *
   * 지표 수집용이라 화면을 막지 않습니다.
   *  - 결과를 기다리지 않고 바로 다음 화면으로 넘어갑니다 (keepalive 로 요청은 살아 있음)
   *  - 실패해도 사용자에게 아무것도 보여주지 않습니다 (콘솔에만 남김)
   *  - 401 이어도 '로그인 만료' 안내를 띄우지 않습니다. 지표 때문에 흐름을 끊을 수는 없으니까요.
   *  - 같은 브리핑은 한 번만 보냅니다 (더블클릭 방지)
   */
  const openedBriefings = new Set();

  async function markBriefingOpened(briefingId) {
    const key = String(briefingId || '');
    if (!key) return { ok: false, code: 'INVALID_INPUT' };
    if (openedBriefings.has(key)) return { ok: true, data: { opened: true } };
    openedBriefings.add(key);

    if (!live('briefing')) {
      await delay(30);
      return { ok: true, data: { opened: true } };
    }

    const res = await request(`/briefings/${encodeURIComponent(key)}/open`, {
      method: 'POST',
      keepalive: true,
      noRetry: true,
      own401: true,
      statusMap: { 401: 'SESSION_EXPIRED', 404: 'NOT_FOUND' },
    });

    if (!res.ok) {
      openedBriefings.delete(key); // 다음 기회에 다시 시도할 수 있게
      console.warn('[API] 브리핑 열람 기록 실패 —', res.code, '(화면에는 영향 없음)');
    }
    return res;
  }

  /**
   * 토큰 재발급
   *   POST /api/auth/refresh
   *   헤더  Authorization: Bearer {accessToken}
   *         X-Refresh-Token: {refreshToken}
   *   응답  200 { success:true, data:{ accessToken, refreshToken }, error:null }
   *         400 형식 오류 / 401 만료·무효 / 500 서버 오류
   */
  /* 로그인이 풀렸을 때 화면에 한 번만 알립니다 */
  let expiredNotified = false;
  function notifySessionExpired() {
    if (expiredNotified) return;
    expiredNotified = true;
    try {
      window.dispatchEvent(new CustomEvent('drjudge:session-expired'));
    } catch (e) {}
  }

  let refreshing = null;

  async function refresh() {
    // 동시에 여러 요청이 401 을 받아도 재발급은 한 번만 합니다
    if (refreshing) return refreshing;

    refreshing = (async () => {
      const rt = getRefreshToken();
      if (!rt) return toError('SESSION_EXPIRED');

      try {
        const res = await fetch(BASE_URL + '/auth/refresh', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${getToken() || ''}`,
            'X-Refresh-Token': rt,
          },
        });
        const json = await res.json().catch(() => ({}));

        if (!res.ok || json.success === false) {
          clearToken();
          Store.signOut();
          notifySessionExpired();
          return toError(res.status === 400 ? 'INVALID_INPUT' : 'SESSION_EXPIRED');
        }

        setTokens(json.data.accessToken, json.data.refreshToken);
        return { ok: true, data: json.data };
      } catch (e) {
        return toError('NETWORK_ERROR');
      } finally {
        refreshing = null;
      }
    })();

    return refreshing;
  }

  async function logout() {
    let server = null;

    if (live('login') && getToken()) {
      // 401 이 와도 재발급을 시도하지 않습니다 — 어차피 나가는 길이라서
      server = await request('/auth/logout', { method: 'POST', noRetry: true });
    }

    clearToken();
    Store.signOut();
    return { ok: true, server };
  }

  /**
   * 회원 탈퇴
   *   DELETE /api/auth/me
   *   헤더  Authorization: Bearer {accessToken}
   *   응답  200 { success:true, data:{ withdrawnAt:"..." }, error:null }
   *         401 인증 필요·토큰 만료 / 500 서버 오류
   *
   * 성공하면 이 기기에 저장된 계정 데이터도 함께 지웁니다.
   */
  async function withdraw() {
    const id = Store.currentId();
    if (!id) return toError('SESSION_EXPIRED');

    if (live('login')) {
      const res = await request('/auth/me', { method: 'DELETE', noRetry: true });
      if (!res.ok) return res;

      clearToken();
      Store.removeAccount(id);
      return { ok: true, data: res.data };
    }

    clearToken();
    Store.removeAccount(id);
    return { ok: true, data: { withdrawnAt: new Date().toISOString() } };
  }

  return {
    LIVE,
    login,
    kakaoLogin,
    kakaoComplete,
    kakaoAuthUrl,
    kakaoRedirectUri,
    signup,
    checkDuplicate,
    requestJudge,
    getJudgment,
    getJudgmentHistory,
    getTodayBriefing,
    getBriefing,
    markBriefingOpened,
    createShareLink,
    getSharedJudgment,
    revokeShareLink,
    publishToFeed,
    getFeedPosts,
    getMyFeedPosts,
    toggleLike,
    deletePost,
    getMe,
    updateMe,
    syncProfile,
    getPointHistory,
    getPointSummary,
    waitForJudgment,
    saveOnboarding,
    updateOnboarding,
    logout,
    withdraw,
    refresh,
    getToken,
    getRefreshToken,
    ERROR_MESSAGE,
  };
})();
